from django.apps import AppConfig


class ComConfig(AppConfig):
    name = 'com'
