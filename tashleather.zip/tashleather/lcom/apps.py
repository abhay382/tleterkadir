from django.apps import AppConfig


class LcomConfig(AppConfig):
    name = 'lcom'
